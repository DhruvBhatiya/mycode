<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div id="um_upload_single" style="display:none"></div>